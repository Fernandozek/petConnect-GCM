from .animal_admin import AnimalAdmin

__all__ = [AnimalAdmin]