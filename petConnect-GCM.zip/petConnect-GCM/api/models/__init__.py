from .animal import Animal
__all__ = [Animal]
